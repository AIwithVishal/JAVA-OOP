create database If not exists medisync;
USE medisync;
-- Patient Table
create table if not exists patients(
patient_id int primary key,
first_name varchar(50) not null,
last_name varchar(50) not null,
contact varchar(15) not null,
created_at TimeStamp Default  Current_TimeStamp);

 -- doctors Table
Create table if not exists doctors (
doctor_id int primary key,
first_name     varchar(50) not null,
last_name      varchar(50)  not null,
contact        varchar(15)   not null,
specialization varchar(100)  not null,
created_at  timeStamp Default  Current_TimeStamp);



--        TABLE: appointments
-- UNIQUE constraint on (doctor_id, date_time) prevents
-- double-booking the same doctor at the same time slot.
create table if not exists appointments(
apointment_id int primary key,
patient_id int not null,
doctor_id int not null,
date_time DATETIME not null,
status   ENUM('Scheduled' ,'Completed', 'Cancelled')	
  not null default 'Scheduled',
  created_at TimeStamp Default  Current_TimeStamp,
CONSTRAINT fk_patient
FOREIGN KEY (patient_id) REFERENCES patients(patient_id)
ON DELETE CASCADE,
CONSTRAINT fk_doctor
FOREIGN KEY (doctor_id)  REFERENCES doctors(doctor_id)
ON DELETE CASCADE,
CONSTRAINT prevent_double_booking
UNIQUE (doctor_id, date_time)
);
-- Putting value in patient table
insert into patients (patient_id,first_name, last_name, contact) VALUES
    (1,'Ahmed',   'Khan',    '0300-1234567'),
    (2,'Sara',    'Ali',     '0311-2345678'),
    (3,'Bilal',   'Raza',    '0321-3456789'),
    (4,'Fatima',  'Sheikh',  '0333-4567890'),
    (5,'Usman',   'Tariq',   '0345-5678901');
    -- Doctors Information
    insert  into doctors (doctor_id,first_name, last_name, contact, specialization) VALUES
    (1,'Dr. Amir',   'Siddiqui',  '0300-9876543', 'Cardiologist'),
    (2,'Dr. Nadia',  'Hussain',   '0311-8765432', 'General Physician'),
    (3,'Dr. Kamran', 'Malik',     '0321-7654321', 'Orthopedic Surgeon'),
    (4,'Dr. Rabia',  'Farooq',    '0333-6543210', 'Neurologist'),
    (5,'Dr. Zain',   'Qureshi',   '0345-5432109', 'Dermatologist');
    -- Sample data appointments
    insert into appointments (apointment_id,patient_id, doctor_id, date_time, status) VALUES
    (1,1, 1, '2025-06-01 09:00:00', 'Scheduled'),
    (2,2, 1, '2025-06-01 10:00:00', 'Scheduled'),
    (3,3, 2, '2025-06-01 09:30:00', 'Scheduled'),
    (4,4, 3, '2025-06-02 11:00:00', 'Scheduled'),
    (5,5, 4, '2025-06-02 14:00:00', 'Scheduled'),
    (6,1, 5, '2025-06-03 08:30:00', 'Scheduled'),
    (7,2, 3, '2025-06-03 10:00:00', 'Completed'),
    (8,3, 5, '2025-06-04 13:00:00', 'Cancelled');

    
 -- View all appointments with patient & doctor names
SELECT
    a.apointment_id,
    CONCAT(p.first_name, ' ', p.last_name)   AS patient_name,
    CONCAT(d.first_name, ' ', d.last_name)   AS doctor_name,
    d.specialization,
    a.date_time,
    a.status
FROM appointments a
JOIN patients p ON a.patient_id = p.patient_id
JOIN doctors  d ON a.doctor_id  = d.doctor_id
ORDER BY a.date_time;

-- All upcoming (scheduled) appointments
SELECT
    a.apointment_id,
    CONCAT(p.first_name, ' ', p.last_name) AS patient,
    CONCAT(d.first_name, ' ', d.last_name) AS doctor,
    a.date_time
FROM appointments a
JOIN patients p ON a.patient_id = p.patient_id
JOIN doctors  d ON a.doctor_id  = d.doctor_id
WHERE a.status = 'Scheduled'
ORDER BY a.date_time;

-- Appointment count per doctor
SELECT
    CONCAT(d.first_name, ' ', d.last_name) AS doctor,
    d.specialization,
    COUNT(a.apointment_id)                AS total_appointments
FROM doctors d
LEFT JOIN appointments a ON d.doctor_id = a.doctor_id
GROUP BY d.doctor_id
ORDER BY total_appointments DESC;

-- TEST: try to book the same doctor at the same time (should FAIL)
INSERT INTO appointments (apointment_id,patient_id, doctor_id, date_time)
VALUES (9,3, 1, '2025-06-01 09:00:00');




  
  


